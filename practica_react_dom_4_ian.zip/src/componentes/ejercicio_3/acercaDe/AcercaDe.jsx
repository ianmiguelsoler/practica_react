import React from "react";

const AcercaDe = () => {
  return (
    <>
      <h2>Búscate la vida, esto es acerca de nosotros, no se que miras.</h2>
    </>
  );
};

export default AcercaDe;