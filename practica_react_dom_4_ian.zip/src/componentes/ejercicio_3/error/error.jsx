

const Error = () => {
    
  return (
    <>
    <div>
       <p>
        <h1>ERROR no te enteras </h1>
       </p>
    </div>
    </>
  );
};

export default Error;
